var xmlSearch_Chunk178Data = "";
xmlSearch_Chunk178Data += '<?xml version=\"1.0\" encoding=\"utf-8\"?><index><!-- saved from url=(0016)http://localhost -->';
xmlSearch_Chunk178Data += '</index>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Search_Chunk178', xmlSearch_Chunk178Data);
