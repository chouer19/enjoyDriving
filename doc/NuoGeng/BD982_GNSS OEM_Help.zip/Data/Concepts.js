var xmlConceptsData = "";
xmlConceptsData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlConceptsData += '<CatapultTargetConcepts>';
xmlConceptsData += '    <!-- saved from url=(0016)http://localhost -->';
xmlConceptsData += '</CatapultTargetConcepts>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Concepts', xmlConceptsData);
